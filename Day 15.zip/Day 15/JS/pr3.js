$(document).ready(function(){
    $("#sort-1").sortable();

    $("#sort-2").sortable();

    $("#sort-1").sortable({
        connectwith: "#sort-2", "#sort-1"
    });
    
    $("#sort-2"),sortable({
        connectwith: "#sort-1", "#sort-2"
    });

});