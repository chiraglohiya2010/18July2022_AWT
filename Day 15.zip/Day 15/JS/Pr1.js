$(document).ready(function(){
    $("#id1").draggable();
    $("#id2").droppable({
        acccept: "#id1",
        drop: function(event, ui){
            $(this).addclass("mycls").find("p").html("Done...");
        }
    });
});